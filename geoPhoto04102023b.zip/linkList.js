var linkList = {
    "general": {
        "daysToKeep": 60
    },
    "albums": [
        {
            "url": "https://www.weather.gov/aprfc/geoPhoto?photoMeta=cap-kuskokwim-river-april-29th-vol-2",
            "created": "2021-04-30",
            "title": "CAP Kuskokwim River April 29th vol 2"
        },
        {
            "url": "https://www.weather.gov/aprfc/geoPhoto?photoMeta=cap-kuskokwim-river-april-29th-vol-1",
            "created": "2021-04-30",
            "title": "CAP Kuskokwim River April 29th vol 1"
        }
    ]
};